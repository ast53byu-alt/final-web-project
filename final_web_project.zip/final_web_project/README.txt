HOW TO PUBLISH THIS SITE ON GITHUB PAGES

1. Create a new GitHub repository.
2. Upload every file and folder from this project.
3. Make sure index.html is in the root of the repository.
4. In GitHub, open the repository, then go to Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and the /(root) folder, then save.
7. Wait a few minutes for GitHub Pages to publish the site.
8. Open the live URL GitHub gives you and test all page links.

Notes:
- Keep the assets folder in the same place.
- Do not rename files unless you also update the links.
- The scratch page uses a live YouTube embed and a live Tableau Public embed, so those work best once the site is hosted online.
